#' @title Generate missing values from a complete dataset.
#'
#' @description Generate missing values under complex requirements of missing mechanisms,
#' missing rates, and missing patterns. This tool is inspired by mice::ampute function, but has different
#' meanings of weighted sum scores and different ways of assigning subsets to missing patterns and choosing
#' lines that should be amputed. And users can further refine the relationships between missing variables and non-missing variables
#' by using this cdampute R package.
#'
#' @details
#'
#' @param compdata is the complete dataframe that need to be amputed, containing n records and p variables.
#' @param prop is the numerical missing rate.
#' @param proptype is the type of missing rate. Missing by 'CASE' and 'CELL' are provided. The default is by 'CASE'.
#' @param mech is one of the 'MCAR','MAR' and 'MNAR' missing mechanisms. 'MAR' is the default.
#' @param varweights is a p#p weight matrix for variables.
#' The i-th row of this matrix defines how the values of all p variables contributes to the
#' missingness of i-th variable. If the value in the i-th row and j-th column of varweights
#' matrix equals to 0, it means that the absence of the i-th variable is not related to the
#' value of the j-th variable. The weighted sum score of each variable is computed by compdata%*%t(varweights) in R.
#' If mech='MCAR', the varweights will not be used.
#' If mech='MAR' or 'MNAR', users can define varweights according to the definitions of mechanisms
#' and their special requirements. If users do not input a weight matrix, varweights will be
#' generated automatically with random values, and the diagonal values will be set to 0 if mech='MAR'.
#' @param patterns is a k*p matrix, where 0 indicates that the value of certain variable is missing,
#' while 1 stands for that the variable is observed. k is the number of missing patterns.
#' @param distribution is a vector (length = p) used to map the weighted sum scores of variables
#' into probabilities of missingness. Four types of missing distributions, 'LEFT','RIGHT','MID' and
#' 'TAIL' are provided. Users can also just input one certain word to represent that generate missing
#' values for all variables using this one type of distribution. The default is 'RIGHT'.
#' @param freq is a vector(length=k), containing the proportion of the compdata assigned to each missing pattern.
#' The sum of all values in a freq vector should be equal to 1.
#'
#' @return return a dataframe with simulated missing values.
#' @export
#' @examples

cdampute <- function(compdata,varweights='none',distribution='RIGHT',patterns,prop,freq,mech='MAR',proptype='CASE'){
  incompdata <- compdata
  rec_num <- nrow(compdata)
  var_num <- ncol(compdata)
  cell_num <- rec_num*var_num

  # reorder the patterns matrix in order based on the number of missing variables, from more to less
  patterns <- cbind(patterns,rowSums(patterns),freq)
  patterns <- patterns[order(patterns[,ncol(patterns)-1]),]

  if(mech %in% c('MAR','MNAR')){
    if(length(varweights)==1){
      print('Generating random varweights...')
      varweights <- matrix(data=runif(var_num*var_num),nrow = var_num,ncol = var_num)
      if(mech=='MAR'){
        varweights_diag <- varweights*diag(1,var_num,var_num)
        varweights <- varweights-varweights_diag
      }
    }
    if(nrow(varweights)!=ncol(varweights)){
      stop('The weight matrix for variables has different numbers of rows and columns.')
    }

    # compute weighted sum scores for each variables
    varweights <- t(varweights)
    compdata <- as.matrix(compdata)
    var_wss <- compdata %*% varweights

    # map weighted sum scores into the probabilities of missing
    if (length(distribution)==1){
      distribution <- rep(distribution,ncol(compdata))
    }else if(!(length(distribution)%in% c(1,ncol(compdata)))){
      stop('The length of the missing distribution vector is not equal to either 1 or the number of variables in the complete dataset.')
    }
    prop_matrix <- matrix(nrow=nrow(compdata),ncol=ncol(compdata))
    for (dis_i in c(1:ncol(compdata))) {
      center_v <- compdata[,dis_i] - mean(compdata[,dis_i])
      if(distribution[dis_i]=='LEFT'){
        prop_matrix[,dis_i] <- 1/(1+exp(center_v))
      }else if(distribution[dis_i]=='RIGHT'){
        prop_matrix[,dis_i] <- 1/(1+exp(-center_v))
      }else if(distribution[dis_i]=='MID'){
        prop_matrix[,dis_i] <- 1-abs(center_v)/max(abs(center_v))
      }else if(distribution[dis_i]=='TAIL'){
        prop_matrix[,dis_i] <- abs(center_v)/max(abs(center_v))
      }
    }

    # reorder the prop_matrix according to the ordered patterns, and ampute the first freq*prop compdata
    prop_df <- data.frame(prop_matrix)
    colnames(prop_matrix) <- colnames(compdata)
    prop_df$id <- c(1:nrow(prop_matrix))
    for (pat_i in 1:nrow(patterns)) {
      pat_freq <- patterns[pat_i,ncol(patterns)]
      miss_index <- which(patterns[pat_i,]==0)
      prop_df$prop_sum <- rowSums(prop_df[,miss_index])
      prop_df <- prop_df[order(-prop_df$prop_sum),]
      if(proptype=='CASE'){
        incomp_size <- round(rec_num*pat_freq*prop,0)
      }else if(proptype=='CELL'){
        incomp_size <- round(cell_num*pat_freq*prop/length(miss_index),0)
      }else{
        stop('Input a wrong proptype.')
      }
      if(incomp_size==0){incomp_size=1}
      ampute_index <- prop_df[1:incomp_size,]$id
      incompdata[ampute_index,miss_index] <- NA
      prop_df <- prop_df[(incomp_size+1):nrow(prop_df),]
    }
  }else if(mech=='MCAR'){
    index_pool <- c(1:rec_num)
    for (pat_i in 1:nrow(patterns)) {
      pat_freq <- patterns[pat_i,ncol(patterns)]
      miss_index <- which(patterns[pat_i,]==0)
      if(proptype=='CASE'){
        incomp_size <- round(rec_num*pat_freq*prop,0)
      }else if(proptype=='CELL'){
        incomp_size <- round(cell_num*pat_freq*prop/length(miss_index),0)
      }else{
        stop('Input a wrong proptype.')
      }
      if(incomp_size==0){incomp_size=1}
      ampute_index <- sample(index_pool,incomp_size)
      incompdata[ampute_index,miss_index] <- NA
      index_pool <- index_pool[-which(index_pool%in%ampute_index)]
    }
  }
  print('Amputed.')
  return(incompdata)
}



